/*
Navicat MySQL Data Transfer

Source Server         : absudbaiu
Source Server Version : 50720
Source Host           : localhost:3306
Source Database       : bankonline

Target Server Type    : MYSQL
Target Server Version : 50720
File Encoding         : 65001

Date: 2018-01-31 08:47:48
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for account
-- ----------------------------
DROP TABLE IF EXISTS `account`;
CREATE TABLE `account` (
  `cardno` varchar(16) NOT NULL,
  `password` varchar(6) NOT NULL,
  `balance` decimal(11,2) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`cardno`),
  KEY `cardno` (`cardno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of account
-- ----------------------------
INSERT INTO `account` VALUES ('1234567890123456', '000111', '110000.56', '1');
INSERT INTO `account` VALUES ('6543210987123456', '223344', '123441.87', '0');
INSERT INTO `account` VALUES ('9876543210123456', '112233', '1233603.09', '1');

-- ----------------------------
-- Table structure for transaction_record
-- ----------------------------
DROP TABLE IF EXISTS `transaction_record`;
CREATE TABLE `transaction_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cardno` varchar(16) NOT NULL,
  `transaction_date` datetime NOT NULL,
  `expense` decimal(11,2) DEFAULT NULL,
  `income` decimal(11,2) DEFAULT NULL,
  `balance` decimal(11,2) NOT NULL,
  `transaction_type` varchar(10) NOT NULL,
  `remark` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cardno` (`cardno`),
  CONSTRAINT `transaction_record_ibfk_1` FOREIGN KEY (`cardno`) REFERENCES `account` (`cardno`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of transaction_record
-- ----------------------------
INSERT INTO `transaction_record` VALUES ('1', '1234567890123456', '2016-04-01 15:47:25', '1000.00', '278.00', '113011.56', '个人账户', 'aaaa');
INSERT INTO `transaction_record` VALUES ('2', '1234567890123456', '2017-11-21 15:52:08', '1722.00', '1000.00', '112289.56', '个人账户', 'bbbb');
INSERT INTO `transaction_record` VALUES ('3', '6543210987123456', '2015-01-01 15:56:54', '200.00', '10000.00', '122741.87', '企业转账', 'qweq');
INSERT INTO `transaction_record` VALUES ('4', '6543210987123456', '2018-01-04 15:58:54', '300.00', '1000.00', '123441.87', '个人转账', 'asdasd');
INSERT INTO `transaction_record` VALUES ('5', '9876543210123456', '2016-11-01 16:00:42', '1231.00', '45555.00', '1191314.09', '企业转账', 'nmcdr');
INSERT INTO `transaction_record` VALUES ('6', '9876543210123456', '2017-08-03 16:04:04', '10000.00', '50000.00', '1231314.09', '企业转账', 'asda');
INSERT INTO `transaction_record` VALUES ('7', '1234567890123456', '2018-01-15 11:06:48', '2000.00', '0.00', '108289.56', '消费', '购物');
INSERT INTO `transaction_record` VALUES ('8', '9876543210123456', '2018-01-15 11:06:48', '0.00', '2000.00', '112289.56', '收账', '购物');
INSERT INTO `transaction_record` VALUES ('9', '1234567890123456', '2018-01-15 11:11:40', '200.00', '0.00', '109889.56', '消费', '购物');
INSERT INTO `transaction_record` VALUES ('10', '9876543210123456', '2018-01-15 11:11:40', '0.00', '200.00', '110289.56', '收账', '购物');
INSERT INTO `transaction_record` VALUES ('11', '1234567890123456', '2018-01-15 14:01:15', '89.00', '0.00', '109911.56', '消费', '购物');
INSERT INTO `transaction_record` VALUES ('12', '9876543210123456', '2018-01-15 14:01:15', '0.00', '89.00', '110089.56', '收账', '购物');
