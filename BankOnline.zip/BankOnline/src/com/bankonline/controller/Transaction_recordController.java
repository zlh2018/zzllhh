package com.bankonline.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bankonline.dbpojo.Transaction_record;
import com.bankonline.formpojo.SeltransForm;
import com.bankonline.service.impl.Transaction_recordServiceImpl;

@Controller
public class Transaction_recordController {

	@Autowired
	private Transaction_recordServiceImpl transaction_recordService;
	@RequestMapping("/selTransaction.do")
	public String selTransaction(SeltransForm seltransForm,HttpServletRequest req){
		List<Transaction_record>transactionlist =transaction_recordService.getTransaction_record(seltransForm);
		req.setAttribute("transactionlist", transactionlist);
		req.setAttribute("seltransForm", seltransForm);
		return "main.jsp";
		
	}
	
}
