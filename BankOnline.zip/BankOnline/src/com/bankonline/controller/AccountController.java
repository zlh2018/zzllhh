package com.bankonline.controller;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bankonline.dbpojo.Account;
import com.bankonline.formpojo.LoginForm;
import com.bankonline.formpojo.TransferForm;
import com.bankonline.service.impl.AccountServiceImpl;

@Controller
public class AccountController {

	@Autowired
	private AccountServiceImpl accountService;
	//登录
    @RequestMapping("/login.do")
    public String login(LoginForm loginForm,HttpSession session){
    	Account account=accountService.getAccountByCardno(loginForm);
    	if(account!=null){
    		if(loginForm.getPassword().equals(account.getPassword())){
    			session.setAttribute("account", account);
    			return "main.jsp";
    		}
    	}
		return "index.jsp";
    	
    }
    //退出
    @RequestMapping("/dropout.do")
    public String dropout(HttpSession session){
    	session.invalidate();
    	return "index.jsp";
    }
    //查询余额
    @RequestMapping("/sel.do")
    public String selBalance(){
    	
		return "main.jsp?flag=1";
    	
    }
    //跳转转账页面
    @RequestMapping("/transfer.do")
    public String transfer(){
		return "main.jsp?flag=2";
    	
    }
    //转账业务
    @RequestMapping("/transaction.do")
    public String transaction(TransferForm transferForm,HttpSession session){
    	Account accountout=(Account)session.getAttribute("account");
    	int num=accountService.transaction(accountout, transferForm);
		return "main.jsp?num="+num;
    	
    }
    //跳转修改密码
    @RequestMapping("/updpwd.do")
    public String updpwd(){
    	return "main.jsp?flag=3";
    }
    //跳转查询
    @RequestMapping("/seltrans.do")
    public String seltrans(){
    	return "main.jsp?flag=4";
    }
    //
    @RequestMapping("/updpassword.do")
    public String updpassword(@Param("newpwd")String newpwd,HttpSession session){
    	Account account=(Account)session.getAttribute("account");
    	account.setPassword(newpwd);
    	int updnum=accountService.updpassword(account);
		return "main.jsp?updnum="+updnum;
    	
    }
    
}
