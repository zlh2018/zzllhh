package com.bankonline.mapper;

import org.springframework.stereotype.Repository;

import com.bankonline.dbpojo.Account;
import com.bankonline.formpojo.LoginForm;
@Repository("accountMapper")
public interface AccountMapper {

	Account getAccountByCardno(LoginForm loginForm);
	
	void updAccount(Account account);
	
	int updpassword(Account account);
}
