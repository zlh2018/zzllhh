package com.bankonline.mapper;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.bankonline.dbpojo.Transaction_record;
import com.bankonline.formpojo.SeltransForm;
@Repository("transaction_recordMapper")
public interface Transaction_recordMapper {

	int addTransaction_record(Transaction_record transaction_record);
	
	List<Transaction_record> getTransaction_record(SeltransForm seltransForm);
}
