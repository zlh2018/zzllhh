package com.bankonline.service;

import java.util.List;

import com.bankonline.dbpojo.Transaction_record;
import com.bankonline.formpojo.SeltransForm;

public interface Transaction_recordService {
	List<Transaction_record> getTransaction_record(SeltransForm seltransForm);
}
