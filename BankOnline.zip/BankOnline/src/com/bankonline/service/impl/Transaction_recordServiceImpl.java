package com.bankonline.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bankonline.dbpojo.Transaction_record;
import com.bankonline.formpojo.SeltransForm;
import com.bankonline.mapper.Transaction_recordMapper;
import com.bankonline.service.Transaction_recordService;
@Service("transaction_recordService")
public class Transaction_recordServiceImpl implements Transaction_recordService {

	@Autowired
	private Transaction_recordMapper transaction_recordMapper;
	
	public List<Transaction_record> getTransaction_record(
			SeltransForm seltransForm) {
		// TODO Auto-generated method stub
		return transaction_recordMapper.getTransaction_record(seltransForm);
	}

}
