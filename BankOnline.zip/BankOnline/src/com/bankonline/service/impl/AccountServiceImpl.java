package com.bankonline.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bankonline.dbpojo.Account;
import com.bankonline.dbpojo.Transaction_record;
import com.bankonline.formpojo.LoginForm;
import com.bankonline.formpojo.TransferForm;
import com.bankonline.mapper.AccountMapper;
import com.bankonline.mapper.Transaction_recordMapper;
import com.bankonline.service.AccountService;

@Service("accountService")
public class AccountServiceImpl implements AccountService {

	@Autowired
	private AccountMapper accountMapper;
	@Autowired
	private Transaction_recordMapper transaction_recordMapper;
	
	public Account getAccountByCardno(LoginForm loginForm) {
	
		return accountMapper.getAccountByCardno(loginForm);
	}

	public int transaction(Account accountout, TransferForm transferForm) {
		String cardno=transferForm.getCardno();
		double money=transferForm.getMoney();
		LoginForm loginForm=new LoginForm();
		loginForm.setCardno(cardno);
		int num=0;
		Account accountin=accountMapper.getAccountByCardno(loginForm);
		
		if(accountin==null){//转入账户不存在
			num=2;
			return num;
		}else{
			if(accountin.getStatus()==0){//转入账户已冻结
				num=3;
				return num;
			}else{
				if(accountout.getBalance()<money){//转出资金不足
					num=4;
					return num;
				}else{
					SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					Date date=new Date();
					accountout.setBalance(accountout.getBalance()-money);	
					accountMapper.updAccount(accountout);
					Transaction_record transaction_record=new Transaction_record();
					transaction_record.setCardno(accountout.getCardno());
					transaction_record.setTransaction_date(sdf.format(date));
					transaction_record.setExpense(money);
					transaction_record.setIncome(0);
					transaction_record.setBalance(accountout.getBalance()-money);
					transaction_record.setTransaction_type("消费");
					transaction_record.setRemark("购物");
					transaction_recordMapper.addTransaction_record(transaction_record);
					
					accountin.setBalance(accountin.getBalance()+money);
					accountMapper.updAccount(accountin);
					Transaction_record transaction_recordin=new Transaction_record();
					transaction_recordin.setCardno(accountin.getCardno());
					transaction_recordin.setTransaction_date(sdf.format(date));
					transaction_recordin.setExpense(0);
					transaction_recordin.setIncome(money);
					transaction_recordin.setBalance(accountout.getBalance()+money);
					transaction_recordin.setTransaction_type("收账");
					transaction_recordin.setRemark("购物");
					num=transaction_recordMapper.addTransaction_record(transaction_recordin);
				}
			}
		}
		
		return num;
	}

	public int updpassword(Account account) {
		return accountMapper.updpassword(account);
		
	}

}
