package com.bankonline.service;

import com.bankonline.dbpojo.Account;
import com.bankonline.formpojo.LoginForm;
import com.bankonline.formpojo.TransferForm;

public interface AccountService {
	Account getAccountByCardno(LoginForm loginForm);
	
	int transaction(Account accountout,TransferForm transferForm);
	
	int updpassword(Account account);
}
