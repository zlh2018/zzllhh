package com.bankonline.dbpojo;

public class Transaction_record {
	private int id;
	private String cardno;
	private String transaction_date;
	private double expense;
	private double income;
	private double balance;
	private String transaction_type;
	private String remark;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCardno() {
		return cardno;
	}

	public void setCardno(String cardno) {
		this.cardno = cardno;
	}

	public String getTransaction_date() {
		return transaction_date;
	}

	public void setTransaction_date(String transactionDate) {
		transaction_date = transactionDate;
	}

	public double getExpense() {
		return expense;
	}

	public void setExpense(double expense) {
		this.expense = expense;
	}

	public double getIncome() {
		return income;
	}

	public void setIncome(double income) {
		this.income = income;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getTransaction_type() {
		return transaction_type;
	}

	public void setTransaction_type(String transactionType) {
		transaction_type = transactionType;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

}
